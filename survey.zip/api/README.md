#Regel

1. Sync først
2. Oppdater filmappen
3. Commit