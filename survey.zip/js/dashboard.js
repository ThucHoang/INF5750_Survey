/*
 *
 *
 *
 */

 function getUserData() {
 	var url = getHost() + '/api/me.json';

 	$.ajax({
 		url: url,
 		contentType: 'application/json',
 		dataType: 'json'
 	}).success(function(data) {
 		refreshDashboardData(data);
 	}).error(function(data) {
 		console.log("Error...");
 	});
 }

 function refreshDashboardData(json) {
 	$('#userInformation').empty();

 	$('#userInformation').append('<h1>Welcome ' + json.name + '!</h1><br />');
 	if(json.organisationUnits.length > 1) {
 		$('#userInformation').append('You are a member of these organization units: ');	
 	}
 	else {
 		$('#userInformation').append('You are a member of this organization unit: ');
 	}
 	
 	console.log(json);
 	console.log(json.organisationUnits.length);


 	for(var i = 1; i <= json.organisationUnits.length; i++) {
 		$('#userInformation').append('<b>');
 		if(i != json.organisationUnits.length) {
 			$('#userInformation').append(json.organisationUnits[i-1].name + ', ');	
 		}
 		else {
 			$('#userInformation').append(json.organisationUnits[i-1].name + '.');
 		}
 		$('#userInformation').append('<br/></b>');
 	}
 	getNumberOfProgramsWithAccess();
 }

 function getNumberOfProgramsWithAccess() {
 	var url = getHost() + '/api/programs.json';
 	var singleEvent = 0;
 	var multiEvent = 0;
 	
 	$.ajax({
 		url: url,
 		contentType: 'application/json',
 		dataType: 'json'
 	}).success(function(data) {
 		var length = data.programs.length;
 		$('#userInformation').append('<br />You have access to ' + data.programs.length + ' programs');
 		console.log(data.programs);

 		for(var i = 0; i < length; i++) {
 			if(data.programs[i].type == 3) {
 				singleEvent++;
 			}
 			else {
 				multiEvent++;
 			}
 		}
 		$('#userInformation').append(' (Where ' + singleEvent + ' are single events and ' + multiEvent + ' are multi events)!');
 	}).error(function(data) {
 		console.log("ERROR WITH # of programs");
 	});
 }