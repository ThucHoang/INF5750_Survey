function getHost() {
	return location.hostname == "localhost" ? "http://localhost/survey" : "http://apps.dhis2.org/demo";
}
